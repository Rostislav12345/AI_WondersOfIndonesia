import google.generativeai as genai
genai.configure(api_key="AIzaSyDvjrkbs2qgjNm3_pc9bkKwZEyW0bD27vc")
model = genai.GenerativeModel("gemini-1.5-flash")
response = model.generate_content("how to center a div?")
print(response.text)